﻿CREATE TABLE [dbo].[Multiplos]
(
	[MultiploId] INT NOT NULL PRIMARY KEY, 
    [Numero] NVARCHAR(30) NOT NULL, 
    [MultiploDe] NVARCHAR(30) NULL, 
    [Mensaje] NVARCHAR(30) NULL
)
