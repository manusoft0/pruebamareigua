﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Datos.ViewModel
{
    public class ViewMultiplo
    {
        public int Numero { get; set; }
        public string MultiploDe { get; set; }
        public string Mensaje { get; set; }
    }
}
